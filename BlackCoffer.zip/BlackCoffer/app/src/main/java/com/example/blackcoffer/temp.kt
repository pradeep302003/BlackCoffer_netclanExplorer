package com.example.blackcoffer

import android.R
import androidx.appcompat.app.ActionBarDrawerToggle


class temp {
    fun somefun(){
//        val menuToggle = ActionBarDrawerToggle(
//            this,
//            drawerLayout,
//            toolbar,
//            R.string.navigation_drawer_open,
//            R.string.navigation_drawer_close
//        )
//        drawerLayout.addDrawerListener(menuToggle)
//        menuToggle.syncState()
//        menuToggle.drawerArrowDrawable = ToolbarHamburgerIcon(this)
    }
}